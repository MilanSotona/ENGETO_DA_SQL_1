INSERT INTO czechia_payroll_value_type (code,name) VALUES
	 (316,'Průměrný počet zaměstnaných osob'),
	 (5958,'Průměrná hrubá mzda na zaměstnance');
