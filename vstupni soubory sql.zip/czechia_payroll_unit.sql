INSERT INTO czechia_payroll_unit (code,name) VALUES
	 (200,'Kč'),
	 (80403,'tis. osob (tis. os.)');
