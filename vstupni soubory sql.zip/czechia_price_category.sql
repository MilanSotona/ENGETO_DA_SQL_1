INSERT INTO czechia_price_category (code,name,price_value,price_unit) VALUES
	 (111101,'Rýže loupaná dlouhozrnná',1.0,'kg'),
	 (111201,'Pšeničná mouka hladká',1.0,'kg'),
	 (111301,'Chléb konzumní kmínový',1.0,'kg'),
	 (111303,'Pečivo pšeničné bílé',1.0,'kg'),
	 (111602,'Těstoviny vaječné',1.0,'kg'),
	 (112101,'Hovězí maso zadní bez kosti',1.0,'kg'),
	 (112201,'Vepřová pečeně s kostí',1.0,'kg'),
	 (112401,'Kuřata kuchaná celá',1.0,'kg'),
	 (112704,'Šunkový salám',1.0,'kg'),
	 (114201,'Mléko polotučné pasterované',1.0,'l');
INSERT INTO czechia_price_category (code,name,price_value,price_unit) VALUES
	 (114401,'Jogurt bílý netučný',150.0,'g'),
	 (114501,'Eidamská cihla',1.0,'kg'),
	 (114701,'Vejce slepičí čerstvá',10.0,'ks'),
	 (115101,'Máslo',1.0,'kg'),
	 (115201,'Rostlinný roztíratelný tuk',1.0,'kg'),
	 (116101,'Pomeranče',1.0,'kg'),
	 (116103,'Banány žluté',1.0,'kg'),
	 (116104,'Jablka konzumní',1.0,'kg'),
	 (117101,'Rajská jablka červená kulatá',1.0,'kg'),
	 (117103,'Papriky',1.0,'kg');
INSERT INTO czechia_price_category (code,name,price_value,price_unit) VALUES
	 (117106,'Mrkev',1.0,'kg'),
	 (117401,'Konzumní brambory',1.0,'kg'),
	 (118101,'Cukr krystalový',1.0,'kg'),
	 (122102,'Přírodní minerální voda uhličitá',1.0,'l'),
	 (212101,'Jakostní víno bílé',0.75,'l'),
	 (213201,'Pivo výčepní, světlé, lahvové',0.5,'l'),
	 (2000001,'Kapr živý',1.0,'kg');
