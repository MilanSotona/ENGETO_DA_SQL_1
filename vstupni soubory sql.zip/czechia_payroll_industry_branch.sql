INSERT INTO czechia_payroll_industry_branch (code,name) VALUES
	 ('A','Zemědělství, lesnictví, rybářství'),
	 ('B','Těžba a dobývání'),
	 ('C','Zpracovatelský průmysl'),
	 ('D','Výroba a rozvod elektřiny, plynu, tepla a klimatiz. vzduchu'),
	 ('E','Zásobování vodou; činnosti související s odpady a sanacemi'),
	 ('F','Stavebnictví'),
	 ('G','Velkoobchod a maloobchod; opravy a údržba motorových vozidel'),
	 ('H','Doprava a skladování'),
	 ('I','Ubytování, stravování a pohostinství'),
	 ('J','Informační a komunikační činnosti');
INSERT INTO czechia_payroll_industry_branch (code,name) VALUES
	 ('K','Peněžnictví a pojišťovnictví'),
	 ('L','Činnosti v oblasti nemovitostí'),
	 ('M','Profesní, vědecké a technické činnosti'),
	 ('N','Administrativní a podpůrné činnosti'),
	 ('O','Veřejná správa a obrana; povinné sociální zabezpečení'),
	 ('P','Vzdělávání'),
	 ('Q','Zdravotní a sociální péče'),
	 ('R','Kulturní, zábavní a rekreační činnosti'),
	 ('S','Ostatní činnosti');
