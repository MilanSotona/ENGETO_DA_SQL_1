INSERT INTO czechia_payroll_calculation (code,name) VALUES
	 (100,'fyzický'),
	 (200,'přepočtený');
